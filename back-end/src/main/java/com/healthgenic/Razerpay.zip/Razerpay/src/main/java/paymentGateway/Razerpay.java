package paymentGateway;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import paymentGateway.controller.RazerpayController;



@SpringBootApplication
@ComponentScan(basePackages = {"paymentGateway.controller"})
public class Razerpay
{

	public static void main(String[] args) 
	{
		SpringApplication.run(Razerpay.class, args);
		System.out.println("It is working");
		
		
		
		
	}

	
	
	

}
