package com.example.Razerpay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RazerpayApplicationTests {

	@Test
	void contextLoads() {
	}

}
