package paymentGateway.entities;

public class Razorpay {
	
	private int amount;
	
	
	
    @Override
	public String toString() {
		return "Razorpay [amount=" + amount + "]";
	}

	public Razorpay() {
		
		this.amount = amount;
	}

	public Razorpay(int amount) {
		
		this.amount = amount;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

}
