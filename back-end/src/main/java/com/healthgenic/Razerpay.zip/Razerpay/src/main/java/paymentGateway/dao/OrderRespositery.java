package paymentGateway.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.razorpay.Order;

import paymentGateway.entities.Orders;

public interface OrderRespositery extends JpaRepository<Orders, Long>

{
     public Orders findByOrderId(String orderId);
}
