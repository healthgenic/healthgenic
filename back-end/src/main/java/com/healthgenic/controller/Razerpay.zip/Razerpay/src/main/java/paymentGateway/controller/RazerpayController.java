package paymentGateway.controller;

import java.util.Map;

import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.razorpay.*;

@RestController

@CrossOrigin(origins="http://localhost:3003/")
public class RazerpayController {
	
	/*
	 * @GetMapping("/get") public String getOrder() { System.out.println("working");
	 * return "done with get"; }
	 */
	
	
	@PostMapping("/create-order")
	@ResponseBody
	public String createOrder(@RequestBody Map<String, Object> data) throws Exception
	{
		System.out.println("On server: working with post axios get ");
		System.out.println(data);
		
		
		
		  int amt = Integer.parseInt(data.get("amount").toString());
		  
		  
		
		  RazorpayClient client = new RazorpayClient("rzp_test_ADUmf8lV5Avque",
		  "M3uvxa92gEFAsF2Ax30cskDh");
		  
		  JSONObject ob = new JSONObject(); 
		  ob.put("amount", amt*100);
		  ob.put("currency", "INR");
		  ob.put("receipt", "txn_123456");
		  
		  //creating new order
		  Order order = client.Orders.create(ob);
		  
		  System.out.println(order);
		 
		 
		 
		
		return order.toString();
	}
	
	
	
	
	
	

}
